//
//  TFWSDK_Image.h
//  TFWSDK
//
//  Created by Willian on 2020/12/16.
//  Copyright © 2020 Willian. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TFWSDK_Image : NSObject

+ (UIImageView *)threeThousandWorld1;

+ (UIImageView *)threeThousandWorld2;

@end

NS_ASSUME_NONNULL_END
