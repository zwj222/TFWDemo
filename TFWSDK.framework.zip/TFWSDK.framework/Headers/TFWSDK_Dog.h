//
//  TFWSDK_Dog.h
//  TFWSDK
//
//  Created by Willian on 2020/12/16.
//  Copyright © 2020 Willian. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TFWSDK_Dog : NSObject

- (void)eat;

@end

NS_ASSUME_NONNULL_END
